import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Trophy, Medal, Search } from "lucide-react";

type Row = {
  player: string;
  team: string;
  matches: number;
  batPts: number;
  bowlPts: number;
  fieldPts: number;
};

const DEMO: Row[] = [
  { player: "J. Smith", team: "1st XI", matches: 6, batPts: 95, bowlPts: 42, fieldPts: 45 },
  { player: "R. Patel", team: "2nd XI", matches: 7, batPts: 60, bowlPts: 88, fieldPts: 22 },
  { player: "A. Khan", team: "Sunday XI", matches: 5, batPts: 70, bowlPts: 50, fieldPts: 39 },
  { player: "M. Lewis", team: "1st XI", matches: 6, batPts: 48, bowlPts: 76, fieldPts: 18 },
];

export default function Leaderboard() {
  const [q, setQ] = useState("");
  const [team, setTeam] = useState<string>("all");

  const rows = useMemo(() => {
    return DEMO
      .filter(r => (team === "all" ? true : r.team === team))
      .filter(r => r.player.toLowerCase().includes(q.toLowerCase()))
      .map(r => ({ ...r, total: r.batPts + r.bowlPts + r.fieldPts }))
      .sort((a, b) => b.total - a.total);
  }, [q, team]);

  const topRuns = useMemo(() => DEMO.slice().sort((a, b) => b.batPts - a.batPts)[0], []);
  const topWkts = useMemo(() => DEMO.slice().sort((a, b) => b.bowlPts - a.bowlPts)[0], []);

  return (
    <main className="mx-auto max-w-5xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Club MVP Standings</h1>
        <Link to="/" className="text-sm text-neutral-600 hover:underline">← Home</Link>
      </div>

      {/* quick highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="flex items-center gap-3 rounded-2xl border p-4">
          <Trophy className="h-6 w-6" />
          <div>
            <div className="text-xs text-neutral-500">Top run-scorer</div>
            <div className="font-semibold">{topRuns.player}</div>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border p-4">
          <Medal className="h-6 w-6" />
          <div>
            <div className="text-xs text-neutral-500">Top wicket-taker</div>
            <div className="font-semibold">{topWkts.player}</div>
          </div>
        </div>
      </div>

      {/* filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-400" />
          <input
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder="Search player…"
            className="pl-8 pr-3 py-2 rounded-xl border w-64"
          />
        </div>
        <select
          value={team}
          onChange={e => setTeam(e.target.value)}
          className="px-3 py-2 rounded-xl border"
        >
          <option value="all">All teams</option>
          <option>1st XI</option>
          <option>2nd XI</option>
          <option>Sunday XI</option>
        </select>
      </div>

      {/* table */}
      <div className="overflow-auto rounded-2xl border">
        <table className="min-w-full text-sm">
          <thead className="bg-neutral-50">
            <tr>
              <th className="px-4 py-2 text-left">#</th>
              <th className="px-4 py-2 text-left">Player</th>
              <th className="px-4 py-2 text-left">Team</th>
              <th className="px-4 py-2 text-right">Bat</th>
              <th className="px-4 py-2 text-right">Bowl</th>
              <th className="px-4 py-2 text-right">Field</th>
              <th className="px-4 py-2 text-right">Matches</th>
              <th className="px-4 py-2 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.player} className="odd:bg-white even:bg-neutral-50">
                <td className="px-4 py-2">{i + 1}</td>
                <td className="px-4 py-2 font-medium">{r.player}</td>
                <td className="px-4 py-2">{r.team}</td>
                <td className="px-4 py-2 text-right tabular-nums">{r.batPts}</td>
                <td className="px-4 py-2 text-right tabular-nums">{r.bowlPts}</td>
                <td className="px-4 py-2 text-right tabular-nums">{r.fieldPts}</td>
                <td className="px-4 py-2 text-right tabular-nums">{r.matches}</td>
                <td className="px-4 py-2 text-right font-semibold tabular-nums">
                  {r.batPts + r.bowlPts + r.fieldPts}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
