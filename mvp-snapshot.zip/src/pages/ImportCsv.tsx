import React, { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { pointsForBatting, pointsForBowling, pointsForFielding } from "../lib/mvp";

type Row = {
  club_name: string;
  match_date: string; // YYYY-MM-DD
  opponent?: string;
  venue?: string;
  competition?: string;
  player_name: string;
  b_runs: number;
  b_4s: number;
  b_6s: number;
  b_50: number; // 0/1
  b_100: number; // 0/1
  o_overs: number; // use decimals like 7.5 for 7.3 overs if needed
  o_maidens: number;
  o_runs: number;
  o_wkts: number;
  c_catches: number;
  c_stumpings: number;
  c_runouts: number;
};

function parseCsv(text: string): Row[] {
  const lines = text.trim().split(/\r?\n/);
  const header = lines.shift()!.split(",");
  return lines
    .filter((l) => l.trim().length)
    .map((line) => {
      const parts = line.split(",").map((s) => s.trim());
      const obj: any = {};
      header.forEach((h, i) => (obj[h] = parts[i] ?? ""));
      const num = (v: any) => (v === "" ? 0 : Number(v));
      return {
        club_name: obj.club_name,
        match_date: obj.match_date,
        opponent: obj.opponent || "",
        venue: obj.venue || "",
        competition: obj.competition || "",
        player_name: obj.player_name,
        b_runs: num(obj.b_runs),
        b_4s: num(obj.b_4s),
        b_6s: num(obj.b_6s),
        b_50: num(obj.b_50),
        b_100: num(obj.b_100),
        o_overs: num(obj.o_overs),
        o_maidens: num(obj.o_maidens),
        o_runs: num(obj.o_runs),
        o_wkts: num(obj.o_wkts),
        c_catches: num(obj.c_catches),
        c_stumpings: num(obj.c_stumpings),
        c_runouts: num(obj.c_runouts),
      } as Row;
    });
}

export default function ImportCsv() {
  const [logs, setLogs] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const log = (m: string) => setLogs((prev) => [m, ...prev]);

  async function upsertClub(name: string) {
    const { data, error } = await supabase
      .from("clubs")
      .upsert({ name }, { onConflict: "name" })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function upsertPlayer(club_id: string, name: string) {
    const { data, error } = await supabase
      .from("players")
      .upsert({ club_id, name }, { onConflict: "club_id,name" })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function getOrCreateMatch(club_id: string, row: Row) {
    const { data: found, error: findErr } = await supabase
      .from("matches")
      .select("*")
      .eq("club_id", club_id)
      .eq("played_on", row.match_date)
      .eq("opposition", row.opponent)
      .limit(1)
      .maybeSingle();
    if (findErr) throw findErr;
    if (found) return found;

    const { data, error } = await supabase
      .from("matches")
      .insert({
        club_id,
        played_on: row.match_date,   // map CSV -> DB
        opposition: row.opponent,
        venue: row.venue,
        competition: row.competition,
      })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function handleCsv(text: string) {
    setBusy(true);
    try {
      const rows = parseCsv(text);
      if (!rows.length) throw new Error("No rows found");
      log(`Parsed ${rows.length} rows`);

      const first = rows[0];
      const club = await upsertClub(first.club_name);
      log(`Club: ${club.name}`);

      const match = await getOrCreateMatch(club.id, first);
      log(`Match on ${match.played_on} vs ${match.opposition || "TBC"}`);

      for (const r of rows) {
        const player = await upsertPlayer(club.id, r.player_name);

        const batPts = pointsForBatting({
          runs: r.b_runs,
          fours: r.b_4s,
          sixes: r.b_6s,
          fifty: !!r.b_50,
          hundred: !!r.b_100,
        });

        const bowlPts = pointsForBowling({
          overs: r.o_overs,
          maidens: r.o_maidens,
          runs: r.o_runs,
          wickets: r.o_wkts,
          three_wkts: r.o_wkts >= 3,
          five_wkts: r.o_wkts >= 5,
        });

        const fldPts = pointsForFielding({
          catches: r.c_catches,
          stumpings: r.c_stumpings,
          runouts: r.c_runouts,
        });

        await supabase.from("batting").upsert(
          {
            match_id: match.id,
            player_id: player.id,
            runs: r.b_runs,
            fours: r.b_4s,
            sixes: r.b_6s,
            fifty: !!r.b_50,
            hundred: !!r.b_100,
            mvp_points: batPts,
          },
          { onConflict: "match_id,player_id" }
        );

        await supabase.from("bowling").upsert(
          {
            match_id: match.id,
            player_id: player.id,
            overs: r.o_overs,
            maidens: r.o_maidens,
            runs: r.o_runs,
            wickets: r.o_wkts,
            five_wkts: r.o_wkts >= 5,
            three_wkts: r.o_wkts >= 3,
            mvp_points: bowlPts,
          },
          { onConflict: "match_id,player_id" }
        );

        await supabase.from("fielding").upsert(
          {
            match_id: match.id,
            player_id: player.id,
            catches: r.c_catches,
            stumpings: r.c_stumpings,
            runouts: r.c_runouts,
            mvp_points: fldPts,
          },
          { onConflict: "match_id,player_id" }
        );

        log(`Saved: ${r.player_name} (Bat ${batPts} / Bowl ${bowlPts} / Field ${fldPts})`);
      }

      log("Import complete ✅");
    } catch (e: any) {
      log(`Error: ${e?.message || e}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">CSV Import</h1>
      <p className="text-gray-600 mb-4">
        Drop a match CSV to create players, match, and stats. See README for format.
      </p>

      <label className="block border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer">
        <input
          type="file"
          accept=".csv"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const text = await file.text();
            handleCsv(text);
          }}
        />
        <div>Click to select a CSV</div>
      </label>

      <button
        className="mt-4 px-4 py-2 rounded-2xl border"
        disabled={busy}
        onClick={async () => {
          const res = await fetch("/templates/match_sample.csv").catch(() => null);
          if (!res || !res.ok) {
            alert("Example CSV not found. Use the one in public/templates/match_sample.csv");
            return;
          }
          const text = await res.text();
          handleCsv(text);
        }}
      >
        {busy ? "Working..." : "Try with example CSV"}
      </button>

      <div className="mt-6">
        <h2 className="font-semibold">Activity</h2>
        <ul className="text-sm mt-2 space-y-1">
          {logs.map((l, i) => (
            <li key={i}>• {l}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
