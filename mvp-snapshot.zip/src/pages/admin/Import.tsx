import { useState } from "react";
import { Link } from "react-router-dom";
import { Upload } from "lucide-react";

type ParsedPreview = {
  fileName: string;
  sizeKB: number;
  team: string;
  opponent: string;
  date: string;
  notes?: string;
};

export default function ImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<ParsedPreview | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] || null;
    setFile(f);
    setPreview(null);
    setMsg(null);
  }

  async function simulateParse() {
    if (!file) return;
    setBusy(true);
    setMsg(null);
    // Pretend we parsed a PDF/CSV — show a human-readable summary
    setTimeout(() => {
      setPreview({
        fileName: file.name,
        sizeKB: Math.round(file.size / 1024),
        team: "1st XI",
        opponent: "Chingford 2nd XI",
        date: new Date().toISOString().slice(0, 10),
        notes: "Parsed batting/bowling cards (demo).",
      });
      setBusy(false);
    }, 600);
  }

  function simulatePublish() {
    setMsg("✅ Import complete (demo). When Supabase is enabled this will save to DB.");
  }

  return (
    <main className="mx-auto max-w-3xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Import Match</h1>
        <Link to="/" className="text-sm text-neutral-600 hover:underline">← Home</Link>
      </div>

      {/* picker */}
      <div className="rounded-2xl border p-6 space-y-3">
        <label className="block text-sm text-neutral-600">Upload Play-Cricket PDF or CSV</label>
        <input type="file" accept=".pdf,.csv" onChange={onPick} />
        <button
          disabled={!file || busy}
          onClick={simulateParse}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border bg-black text-white disabled:opacity-50"
        >
          <Upload className="h-4 w-4" />
          {busy ? "Parsing…" : "Parse file"}
        </button>
      </div>

      {/* preview */}
      {preview && (
        <div className="rounded-2xl border p-6 space-y-3">
          <div className="font-semibold">Preview</div>
          <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
            <dt className="text-neutral-500">File</dt><dd>{preview.fileName} ({preview.sizeKB} KB)</dd>
            <dt className="text-neutral-500">Team</dt><dd>{preview.team}</dd>
            <dt className="text-neutral-500">Opponent</dt><dd>{preview.opponent}</dd>
            <dt className="text-neutral-500">Date</dt><dd>{preview.date}</dd>
          </dl>
          {preview.notes && <p className="text-sm text-neutral-600">{preview.notes}</p>}

          <div className="pt-2">
            <button
              onClick={simulatePublish}
              className="px-4 py-2 rounded-xl border bg-emerald-600 text-white"
            >
              Publish (demo)
            </button>
          </div>
        </div>
      )}

      {msg && <div className="text-sm">{msg}</div>}

      <p className="text-xs text-neutral-500">
        Later: once Supabase is enabled we’ll create a match row, insert parsed cards,
        call the “zero-rows” RPC, and publish. For now this page is a safe stub.
      </p>
    </main>
  );
}
