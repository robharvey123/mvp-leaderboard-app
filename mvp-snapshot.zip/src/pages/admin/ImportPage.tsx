import { useEffect, useState } from "react";
import { parsePlayCricketPdf, type ParsedMatch } from "../../lib/parsePlayCricketPdf";
import { saveParsedMatches } from "../../lib/saveParsedMatches";
import type { PointsConfig } from "../../lib/calcPoints";
import { calcPoints } from "../../lib/calcPoints";
import { supabase } from "../../lib/supabaseClient";

type MatchDraft = ParsedMatch;

export default function ImportPage() {
  const [drafts, setDrafts] = useState<MatchDraft[]>([]);
  const [cfg, setCfg] = useState<PointsConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [active, setActive] = useState(0);
  const [saved, setSaved] = useState<Array<{ matchId: string; playCricketId?: string }>>([]);

  // Load latest points config
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("points_config")
        .select("*")
        .order("updated_at", { ascending: false })
        .limit(1);

      if (data?.length) {
        const c: any = data[0];
        setCfg({
          batting_run: Number(c.batting_run ?? 1),
          fifty_bonus: Number(c.fifty_bonus ?? 0),
          hundred_bonus: Number(c.hundred_bonus ?? 0),
          wicket: Number(c.wicket ?? 20),
          maiden: Number(c.maiden ?? 4),
          catch: Number(c.catch ?? 5),
          stumping: Number(c.stumping ?? 7),
          runout: Number(c.runout ?? 6),
          assist: Number(c.assist ?? 3),
          duck_penalty: Number(c.duck_penalty ?? 5),
          drop_penalty: Number(c.drop_penalty ?? 2),
        });
      } else {
        setCfg({
          batting_run: 1,
          fifty_bonus: 0,
          hundred_bonus: 0,
          wicket: 20,
          maiden: 4,
          catch: 5,
          stumping: 7,
          runout: 6,
          assist: 3,
          duck_penalty: 5,
          drop_penalty: 2,
        });
      }
    })();
  }, []);

  async function handleFiles(list: FileList | null) {
    if (!list) return;
    const files = Array.from(list);
    const parsed: MatchDraft[] = [];
    for (const f of files) {
      try {
        const m = await parsePlayCricketPdf(f);
        parsed.push(m);
      } catch (e) {
        console.error("Failed to parse", f.name, e);
      }
    }
    setDrafts(parsed);
    setActive(0);
    setSaved([]);
  }

  function updateExtra(matchIndex: number, player: string, key: keyof MatchDraft["players"][number]["extras"], val: number) {
    setDrafts((old) => {
      const next = structuredClone(old);
      const p = next[matchIndex]?.players.find((x) => x.name === player);
      if (p) (p.extras as any)[key] = val;
      return next;
    });
  }

  async function saveAll() {
    if (!cfg || drafts.length === 0) return;
    setSaving(true);
    try {
      const result = await saveParsedMatches(drafts, cfg);
      setSaved(result);
      alert("All matches saved!");
    } catch (e: any) {
      console.error(e);
      alert(e.message || "Save failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-xl font-semibold">Multi‑Match Import</h1>
      <p className="opacity-80">Drop Play‑Cricket “Print” PDFs. Edit extras per player, then Save All.</p>

      <div className="border border-dashed rounded-xl p-6">
        <input type="file" multiple accept="application/pdf" onChange={(e) => handleFiles(e.target.files)} />
      </div>

      {drafts.length > 0 && (
        <div className="space-y-3">
          <div className="flex gap-2 flex-wrap">
            {drafts.map((m, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={`px-3 py-1 rounded-xl border ${i === active ? "bg-black/10" : "bg-white/5"}`}
              >
                {m.matchDate || "Unknown"} — {m.team} vs {m.opponent}
              </button>
            ))}
          </div>

          <MatchEditor match={drafts[active]} index={active} onChangeExtra={updateExtra} cfg={cfg} />

          <div className="pt-2">
            <button disabled={saving} onClick={saveAll} className="bg-blue-600 text-white px-4 py-2 rounded-xl">
              {saving ? "Saving…" : "Save All Matches"}
            </button>
          </div>

          {saved.length > 0 && (
            <div className="mt-3 bg-white/5 rounded-2xl p-3">
              <div className="font-semibold mb-2">Saved matches</div>
              <ul className="list-disc pl-5 space-y-1">
                {saved.map((s, i) => (
                  <li key={i}>
                    Match ID:{" "}
                    <a className="underline" href={`/matches/${s.matchId}`}>
                      {s.matchId}
                    </a>
                    {s.playCricketId ? <> · Play‑Cricket: {s.playCricketId}</> : null}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MatchEditor({
  match,
  index,
  onChangeExtra,
  cfg,
}: {
  match: MatchDraft;
  index: number;
  onChangeExtra: (mi: number, player: string, key: any, val: number) => void;
  cfg: PointsConfig | null;
}) {
  return (
    <div className="bg-white/5 rounded-2xl p-4">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div>
          <div className="text-lg font-semibold">
            {match.team} vs {match.opponent}
          </div>
          <div className="text-sm opacity-75">
            Date: {match.matchDate} {match.playCricketId ? `• ID ${match.playCricketId}` : ""}
          </div>
          {(match.teamScore || match.opponentScore) && (
            <div className="text-sm opacity-75">
              Score: {match.teamScore} vs {match.opponentScore}
            </div>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[900px] w-full text-sm">
          <thead className="text-left opacity-80">
            <tr>
              <th className="py-2 pr-3">Player</th>
              <th className="py-2 pr-3">Runs</th>
              <th className="py-2 pr-3">4s</th>
              <th className="py-2 pr-3">6s</th>
              <th className="py-2 pr-3">Overs</th>
              <th className="py-2 pr-3">Mdns</th>
              <th className="py-2 pr-3">Wkts</th>
              <th className="py-2 pr-3">Catches</th>
              <th className="py-2 pr-3">Stump</th>
              <th className="py-2 pr-3">Run‑outs</th>
              <th className="py-2 pr-3">Assists</th>
              <th className="py-2 pr-3">Drops</th>
              <th className="py-2 pr-3">Ducks</th>
              <th className="py-2 pr-3 text-right">Pts</th>
            </tr>
          </thead>
          <tbody>
            {match.players.map((p) => {
              const preview = cfg
                ? calcPoints(
                    { runs: p.batting?.runs, fours: p.batting?.fours, sixes: p.batting?.sixes },
                    { wickets: p.bowling?.wickets, maidens: p.bowling?.maidens },
                    {
                      catches: p.extras.catches || 0,
                      stumpings: p.extras.stumpings || 0,
                      runouts: p.extras.runouts || 0,
                      assists: p.extras.assists || 0,
                    },
                    { ducks: p.extras.ducks || 0, drops: p.extras.drops || 0 },
                    cfg
                  )
                : { total: 0, battingPts: 0, bowlingPts: 0, fieldingPts: 0, penaltyPts: 0 };
              return (
                <tr key={p.name} className="border-t border-white/10">
                  <td className="py-2 pr-3 font-medium">{p.name}</td>
                  <td className="py-2 pr-3">{p.batting?.runs ?? "—"}</td>
                  <td className="py-2 pr-3">{p.batting?.fours ?? "—"}</td>
                  <td className="py-2 pr-3">{p.batting?.sixes ?? "—"}</td>
                  <td className="py-2 pr-3">{p.bowling?.overs ?? "—"}</td>
                  <td className="py-2 pr-3">{p.bowling?.maidens ?? "—"}</td>
                  <td className="py-2 pr-3">{p.bowling?.wickets ?? "—"}</td>

                  {(["catches", "stumpings", "runouts", "assists", "drops", "ducks"] as const).map((k) => (
                    <td key={k} className="py-2 pr-3">
                      <input
                        type="number"
                        min={0}
                        value={Number((p.extras as any)[k] || 0)}
                        onChange={(e) => onChangeExtra(index, p.name, k as any, Number(e.target.value))}
                        className="w-20 px-2 py-1 rounded border bg-transparent"
                      />
                    </td>
                  ))}

                  <td className="py-2 pr-3 text-right font-semibold">{Math.round(preview.total)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
