// src/pages/admin/ImportCsv.tsx
import { useState } from "react";
import { supabase } from "../../lib/supabaseClient";

export default function ImportCsv() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  // ⬇️ PASTE YOUR PARSER OUTPUT INTO "parsed" OR REPLACE IT WITH REAL VALUES
  async function handleImport() {
    setBusy(true);
    setMsg(null);
    try {
      // Example "parsed" shape. Replace with real values from your CSV/PDF parser.
      const parsed = {
        club_id: "00000000-0000-0000-0000-000000000000",   // <- real club_id
        team_id: "00000000-0000-0000-0000-000000000000",   // <- real team_id
        opponent: "Chingford 2nd XI",
        match_date: "2025-08-09",                          // yyyy-mm-dd
        batting: [
          // minimum fields your table expects + player_id
          // { player_id: "...", position: 1, runs: 42, balls: 55, fours: 6, sixes: 1, strike_rate: null }
        ],
        bowling: [
          // { player_id: "...", overs: 8, maidens: 2, runs: 24, wickets: 3, economy: null }
        ],
        fielding: [
          // { player_id: "...", catches: 1, stumpings: 0, runouts: 0, drops: 0, misfields: 0 }
        ],
      };

      // 1) Create the match row
      const { data: match, error: mErr } = await supabase
        .from("matches")
        .insert({
          club_id: parsed.club_id,
          team_id: parsed.team_id,
          opponent: parsed.opponent,
          match_date: parsed.match_date,
          source: "import",
          parse_status: "draft",
        })
        .select("id")
        .single();
      if (mErr) throw mErr;

      // 2) Insert any parsed stat rows that actually exist
      if (parsed.batting?.length) {
        await supabase
          .from("batting_cards")
          .insert(parsed.batting.map((r: any) => ({ match_id: match.id, ...r })));
      }
      if (parsed.bowling?.length) {
        await supabase
          .from("bowling_cards")
          .insert(parsed.bowling.map((r: any) => ({ match_id: match.id, ...r })));
      }
      if (parsed.fielding?.length) {
        await supabase
          .from("fielding_cards")
          .insert(parsed.fielding.map((r: any) => ({ match_id: match.id, ...r })));
      }

      // 3) 🔐 ZERO-ROWS RULE — THIS IS THE LINE YOU ASKED ABOUT
      //    Adds zero-stat rows for the rest of the squad so all XI appear in reports.
      const { error: zeroErr } = await supabase.rpc("upsert_zero_rows", { p_match_id: match.id });
      if (zeroErr) throw zeroErr;

      // 4) Publish
      await supabase.from("matches").update({ parse_status: "published" }).eq("id", match.id);

      setMsg("Import complete ✅");
    } catch (e: any) {
      console.error(e);
      setMsg(`Import failed: ${e.message || e}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-6 space-y-3">
      <h1 className="text-2xl font-bold">Import Match</h1>
      {/* Replace this with your real dropzone / file picker */}
      <button
        onClick={handleImport}
        disabled={busy}
        className="px-4 py-2 rounded bg-black text-white disabled:opacity-50"
      >
        {busy ? "Importing…" : "Run Demo Import"}
      </button>
      {msg && <div className="text-sm text-neutral-700">{msg}</div>}
    </div>
  );
}
