import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { calcBattingPoints, calcBowlingPoints, type Formula } from "@/lib/scoring/engine";

export default function ScoringConfigPage() {
  const [formula, setFormula] = useState<Formula | null>(null);

  useEffect(() => { (async () => {
    const { data } = await supabase
      .from("scoring_configs")
      .select("formula_json")
      .eq("is_active", true)
      .limit(1)
      .maybeSingle();
    setFormula((data?.formula_json as Formula) || {
      batting:{per_run:1,boundary_4:1,boundary_6:2,milestones:[{at:50,bonus:10},{at:100,bonus:25}],duck_penalty:-10},
      bowling:{per_wicket:15,maiden_over:5,three_for_bonus:10,five_for_bonus:25,
               economy_bands:[{max:3,bonus:10},{min:8,penalty:-10}]},
      fielding:{catch:5,stumping:8,runout:6,drop_penalty:-5,misfield_penalty:-2},
    });
  })(); }, []);

  async function save() {
    if (!formula) return;
    await supabase.from("scoring_configs").insert({ name: "v1", version: 1, formula_json: formula, is_active: true });
  }

  if (!formula) return <div className="p-6">Loading…</div>;

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">Scoring Config</h1>
      <textarea className="w-full h-72 font-mono p-3 border rounded"
        value={JSON.stringify(formula, null, 2)}
        onChange={e => setFormula(JSON.parse(e.target.value))} />
      <button onClick={save} className="px-4 py-2 rounded bg-black text-white">Save New Version</button>
      <div>
        <h2 className="font-semibold mt-4">Preview</h2>
        <pre className="text-sm">Batting 72(10x4,2x6): {calcBattingPoints(formula.batting,{runs:72,balls:55,fours:10,sixes:2,dismissal:"caught"})}</pre>
        <pre className="text-sm">Bowling 8-2-24-3: {calcBowlingPoints(formula.bowling,{overs:8,maidens:2,runs:24,wickets:3})}</pre>
      </div>
    </div>
  );
}
