import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Upload, Trophy, CalendarDays } from "lucide-react";
import QuickTile from "../components/QuickTile";
import LeaderboardMini from "../components/LeaderboardMini";
import RecentMatches from "../components/RecentMatches";

type ClubRow = { id: string; slug: string; name: string; brand?: { primary?: string; logo_url?: string } };

const DEFAULT_CLUB: ClubRow = {
  id: "local",
  slug: "brookweald",
  name: "Brookweald CC",
  brand: { primary: "#059669", logo_url: "/club-logos/brookweald.png" },
};

const demoLeaderboard = [
  { player: "J. Smith", points: 182, badges: ["50", "3-for"] },
  { player: "R. Patel", points: 170, badges: ["5-for"] },
  { player: "A. Khan", points: 159 },
];
const demoMatches = [
  { date: "Sat 9 Aug", opponent: "vs Chingford 2nd XI", result: "W", margin: "by 4 wkts" },
  { date: "Sat 2 Aug", opponent: "vs Hutton 3rd XI", result: "L", margin: "by 12 runs" },
  { date: "Sun 27 Jul", opponent: "vs Orsett CC", result: "W", margin: "by 35 runs" },
];

function tint(hex: string, pct: number) {
  const n = hex.replace("#", "");
  const full = n.length === 3 ? n.split("").map(c => c + c).join("") : n;
  const num = parseInt(full, 16);
  const r = Math.min(255, Math.round(((num >> 16) & 255) * (1 + pct)));
  const g = Math.min(255, Math.round(((num >> 8) & 255) * (1 + pct)));
  const b = Math.min(255, Math.round((num & 255) * (1 + pct)));
  return `#${[r, g, b].map(v => v.toString(16).padStart(2, "0")).join("")}`;
}

export default function Home() {
  const [params] = useSearchParams();
  const slug = useMemo(() => params.get("club") || "brookweald", [params]);

  const [club, setClub] = useState<ClubRow | null>(null);
  const [loading, setLoading] = useState(true);

  // Only try Supabase if env vars exist; otherwise fall back instantly.
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const SUPA_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

  useEffect(() => {
    (async () => {
      if (!SUPA_URL || !SUPA_KEY) {
        setClub(null); // use fallback
        setLoading(false);
        return;
      }
      try {
        const url =
          `${SUPA_URL}/rest/v1/clubs` +
          `?select=id,slug,name,brand&slug=eq.${slug}`;
        const r = await fetch(url, {
          headers: { apikey: SUPA_KEY, Authorization: `Bearer ${SUPA_KEY}` },
        });
        const rows = await r.json();
        setClub(rows?.[0] || null);
      } catch {
        setClub(null); // use fallback if request fails
      } finally {
        setLoading(false);
      }
    })();
  }, [slug, SUPA_URL, SUPA_KEY]);

  if (loading) return <main className="p-6">Loading…</main>;

  const ui = club ?? DEFAULT_CLUB; // fallback guarantees UI
  const accent = ui.brand?.primary ?? "#059669";
  const gradientStyle = { backgroundImage: `linear-gradient(135deg, ${accent}, ${tint(accent, 0.2)})` };

  return (
    <main className="mx-auto max-w-5xl p-6 space-y-6">
      {/* Hero */}
      <div className="rounded-3xl border text-white p-6 bg-gradient-to-br" style={gradientStyle}>
        <div className="flex items-center gap-3">
          {ui.brand?.logo_url && (
            <img src={ui.brand.logo_url} alt={ui.name} className="h-10 w-10 rounded-md bg-white/10 p-1 border border-white/20" />
          )}
          <div>
            <h1 className="text-2xl font-bold">{ui.name}</h1>
            <p className="opacity-90">Season 2025 • Multi-team stats &amp; leaderboards</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-5">
          <QuickTile to="/admin/import" title="Import Match" subtitle="Upload Play-Cricket PDF" icon={<Upload className="h-5 w-5" />} />
          <QuickTile to="/leaderboard"  title="Leaderboard"  subtitle="See MVP standings"     icon={<Trophy className="h-5 w-5" />} />
          <QuickTile to="/fixtures"     title="Fixtures & Results" subtitle="Upcoming and past games" icon={<CalendarDays className="h-5 w-5" />} />
        </div>
      </div>

      {/* Panels */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2"><LeaderboardMini rows={demoLeaderboard} /></div>
        <div><RecentMatches items={demoMatches} /></div>
      </div>
    </main>
  );
}
