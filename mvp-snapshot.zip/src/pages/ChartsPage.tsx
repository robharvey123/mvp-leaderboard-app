import { CombinedDashboard } from "../charts"; // if you placed Pack 4 at src/charts/index.ts
// If your path is different, update the import accordingly.
// Types are also re-exported there.
import type { PlayerSeason, PlayerMatch, TeamStats } from "../charts";

import { teams, playersByTeam, matchesByTeam, teamStatsByTeam } from "../data/mvpDemoData";

export default function ChartsPage() {
  return (
    <div className="p-6">
      <CombinedDashboard
        teams={teams}
        teamStatsByTeam={teamStatsByTeam as Record<string, TeamStats>}
        playersByTeam={playersByTeam as Record<string, PlayerSeason[]>}
        matchesByTeam={matchesByTeam as Record<string, PlayerMatch[]>}
        defaultTeam="overall"
      />
    </div>
  );
}
