console.log("SUPA_URL =", import.meta.env.VITE_SUPABASE_URL);
console.log("SUPA_KEY starts =", (import.meta.env.VITE_SUPABASE_ANON_KEY || "").slice(0, 6));

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css"; // keep this line

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);
