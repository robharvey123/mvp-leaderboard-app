import { useMemo, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Upload, Trophy, CalendarDays } from "lucide-react";
import QuickTile from "../components/QuickTile";
import LeaderboardMini from "../components/LeaderboardMini";
import RecentMatches from "../components/RecentMatches";
import OrgProvider, { useOrg } from "../context/OrgContext";
import ClubThemeProvider, { useClubTheme } from "../components/ClubThemeProvider";
import OrgSwitcher from "../components/OrgSwitcher";
import { supabase } from "../lib/supabaseClient";

const demoLeaderboard = [
  { player: "J. Smith", points: 182, badges: ["50", "3-for"] },
  { player: "R. Patel", points: 170, badges: ["5-for"] },
  { player: "A. Khan", points: 159 },
];
const demoMatches = [
  { date: "Sat 9 Aug", opponent: "vs Chingford 2nd XI", result: "W", margin: "by 4 wkts" },
  { date: "Sat 2 Aug", opponent: "vs Hutton 3rd XI", result: "L", margin: "by 12 runs" },
  { date: "Sun 27 Jul", opponent: "vs Orsett CC", result: "W", margin: "by 35 runs" },
];
const APP_VERSION = import.meta.env.VITE_APP_VERSION || "v0.3.0";

export default function Home() {
  const [params] = useSearchParams();
  const preferredSlug = useMemo(() => params.get("club") || "brookweald", [params]);
  return (
    <OrgProvider preferredSlug={preferredSlug}>
      <ThemedHome />
    </OrgProvider>
  );
}

function ThemedHome() {
  const { org, loading } = useOrg();

  // DEBUG: prove the fetch is happening
  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from("clubs")
        .select("id,slug,name,brand")
        .eq("slug", org?.slug || "brookweald")
        .maybeSingle();
      console.log("clubs fetch →", { data, error });
    })();
  }, [org?.slug]);

  if (loading) return <main className="p-6">Loading club…</main>;

  return (
    <ClubThemeProvider org={org ?? { id:"local", slug:"brookweald", name:"Brookweald CC", brand:{ primary:"#059669", logo_url:"/club-logos/brookweald.png" } } as any}>
      <HomeInner />
    </ClubThemeProvider>
  );
}

function HomeInner() {
  const { theme } = useClubTheme();
  return (
    <main className="mx-auto max-w-5xl p-6 space-y-6">
      <div className="flex items-center justify-between text-sm text-neutral-500">
        <OrgSwitcher />
        <div className="flex items-center gap-3">
          <a href="/health.html" className="hover:underline">Health</a>
          <span className="tabular-nums">{APP_VERSION}</span>
        </div>
      </div>

      <div className="rounded-3xl border text-white p-6 bg-gradient-to-br" style={theme.gradientStyle}>
        <div className="flex items-center gap-3">
          {theme.logoUrl ? (
            <img src={theme.logoUrl} alt={theme.name} className="h-10 w-10 rounded-md bg-white/10 p-1 border border-white/20" />
          ) : null}
          <div>
            <h1 className="text-2xl font-bold">{theme.name}</h1>
            <p className="opacity-90">Season 2025 • Multi-team stats & leaderboards</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-5">
          <QuickTile to="/admin/import" title="Import Match" subtitle="Upload Play-Cricket PDF" icon={<Upload className="h-5 w-5" />} />
          <QuickTile to="/leaderboard" title="Leaderboard" subtitle="See MVP standings" icon={<Trophy className="h-5 w-5" />} />
          <QuickTile to="/fixtures" title="Fixtures & Results" subtitle="Upcoming and past games" icon={<CalendarDays className="h-5 w-5" />} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2"><LeaderboardMini rows={demoLeaderboard} /></div>
        <div><RecentMatches items={demoMatches} /></div>
      </div>
    </main>
  );
}
