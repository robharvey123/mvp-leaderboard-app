import React, { createContext, useContext, useMemo } from "react";
import type { Org } from "../context/OrgContext";

type ClubTheme = {
  name: string;
  logoUrl?: string;
  accentHex: string;
  gradientStyle: React.CSSProperties;
};

const ThemeCtx = createContext<{ theme: ClubTheme }>({
  theme: {
    name: "Club",
    accentHex: "#059669",
    logoUrl: undefined,
    gradientStyle: { backgroundImage: "linear-gradient(135deg,#059669,#10b981)" },
  },
});

function tint(hex: string, pct: number) {
  const n = hex.replace("#", "");
  const full = n.length === 3 ? n.split("").map(c => c + c).join("") : n;
  const num = parseInt(full, 16);
  const r = Math.min(255, Math.round(((num >> 16) & 255) * (1 + pct)));
  const g = Math.min(255, Math.round(((num >> 8) & 255) * (1 + pct)));
  const b = Math.min(255, Math.round((num & 255) * (1 + pct)));
  return `#${[r, g, b].map(v => v.toString(16).padStart(2, "0")).join("")}`;
}

export function useClubTheme() {
  return useContext(ThemeCtx);
}

export default function ClubThemeProvider({
  org,
  children,
}: {
  org?: Org;
  children: React.ReactNode;
}) {
  const theme = useMemo<ClubTheme>(() => {
    const accent = org?.brand?.primary || "#059669";
    const light = tint(accent, 0.2);
    return {
      name: org?.name || "Club",
      logoUrl: org?.brand?.logo_url,
      accentHex: accent,
      gradientStyle: { backgroundImage: `linear-gradient(135deg, ${accent}, ${light})` },
    };
  }, [org]);

  return <ThemeCtx.Provider value={{ theme }}>{children}</ThemeCtx.Provider>;
}
