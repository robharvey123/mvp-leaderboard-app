import { useNavigate, useLocation } from "react-router-dom";
import { useOrg } from "../context/OrgContext";

export default function OrgSwitcher() {
  const nav = useNavigate();
  const { pathname, search } = useLocation();
  const { clubs } = useOrg(); // clubs list comes from Supabase via OrgContext

  const params = new URLSearchParams(search);

  if (!clubs?.length) return null;

  return (
    <div className="flex gap-2 flex-wrap">
      {clubs.map((c) => (
        <button
          key={c.slug}
          onClick={() => {
            params.set("club", c.slug);
            nav(`${pathname}?${params.toString()}`);
          }}
          className="px-3 py-1.5 rounded-full border text-sm hover:bg-neutral-50 focus:outline-none focus-visible:ring-2 ring-offset-2"
          title={`Switch to ${c.name}`}
        >
          {c.name}
        </button>
      ))}
    </div>
  );
}
