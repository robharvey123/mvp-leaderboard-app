import { motion } from "framer-motion";
import { ReactNode } from "react";
import { cn } from "../lib/utils";

export default function StatCard({
  title, value, sub, icon, className,
}: { title:string; value:string|number; sub?:string; icon?:ReactNode; className?:string }) {
  return (
    <motion.div
      className={cn("rounded-2xl border bg-white/70 backdrop-blur p-4 shadow-sm", className)}
      initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-wide text-gray-500">{title}</div>
          <div className="text-2xl font-semibold mt-1">{value}</div>
          {sub && <div className="text-xs text-gray-500 mt-1">{sub}</div>}
        </div>
        {icon && <div className="opacity-70">{icon}</div>}
      </div>
    </motion.div>
  );
}
