import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import ImportPage from "./pages/admin/ImportPage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/admin/import" element={<ImportPage />} />
        <Route path="*" element={<div className="p-6">Not found</div>} />
      </Routes>
    </BrowserRouter>
  );
}
