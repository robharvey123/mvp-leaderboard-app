export type Formula = {
  batting:{per_run:number;boundary_4:number;boundary_6:number;milestones:{at:number;bonus:number}[];duck_penalty:number};
  bowling:{per_wicket:number;maiden_over:number;three_for_bonus?:number;five_for_bonus?:number;
           economy_bands?:{min?:number;max?:number;bonus?:number;penalty?:number}[]};
  fielding:{catch:number;stumping:number;runout:number;drop_penalty:number;misfield_penalty:number};
};

export function calcBattingPoints(f: Formula['batting'], s:{runs:number;fours:number;sixes:number;balls:number;dismissal?:string}) {
  let pts = s.runs*f.per_run + s.fours*f.boundary_4 + s.sixes*f.boundary_6;
  for (const m of f.milestones) if (s.runs >= m.at) pts += m.bonus;
  if (s.runs===0 && s.balls>0 && s.dismissal && s.dismissal!=='Did not bat') pts += f.duck_penalty;
  return pts;
}
export function calcBowlingPoints(f: Formula['bowling'], s:{overs:number;maidens:number;runs:number;wickets:number}) {
  let pts = s.wickets*f.per_wicket + s.maidens*f.maiden_over;
  if (f.three_for_bonus && s.wickets>=3) pts += f.three_for_bonus;
  if (f.five_for_bonus && s.wickets>=5) pts += f.five_for_bonus;
  const econ = s.overs>0 ? s.runs/s.overs : undefined;
  if (econ && f.economy_bands) for (const b of f.economy_bands) {
    if (b.max!==undefined && econ<=b.max && b.bonus) pts += b.bonus;
    if (b.min!==undefined && econ>=b.min && b.penalty) pts += b.penalty;
  }
  return pts;
}
