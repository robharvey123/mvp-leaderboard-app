import { supabase } from "./supabaseClient";
import type { ParsedMatch } from "./parsePlayCricketPdf";
import type { PointsConfig } from "./calcPoints";
import { calcPoints } from "./calcPoints";

export async function saveParsedMatches(matches: ParsedMatch[], cfg: PointsConfig) {
  const saved: Array<{ matchId: string; playCricketId?: string }> = [];

  for (const m of matches) {
    // ---- 1) Upsert match (prefer Play‑Cricket ID if present)
    const base = {
      play_cricket_id: m.playCricketId ?? null,
      team: m.team,
      opponent: m.opponent,
      match_date: m.matchDate,
    };

    const conflictTarget = m.playCricketId ? "play_cricket_id" : "team,opponent,match_date";

    const { data: matchRow, error: matchErr } = await supabase
      .from("matches")
      .upsert(base, { onConflict: conflictTarget })
      .select()
      .single();
    if (matchErr) throw matchErr;

    // ---- 2) Players + appearances + stats + events + points
    // helper: get or create player id
    async function getPlayerId(name: string) {
      const { data, error } = await supabase
        .from("players")
        .upsert({ name }, { onConflict: "name" })
        .select()
        .single();
      if (error) throw error;
      return data!.id as string;
    }

    // Keep per‑appearance totals to compute match MVP
    const appearanceTotals: Array<{ player: string; total: number }> = [];

    for (const p of m.players) {
      const playerId = await getPlayerId(p.name);

      // Appearance (unique on match_id + player_id)
      const { data: app, error: appErr } = await supabase
        .from("appearances")
        .upsert({ match_id: matchRow.id, player_id: playerId }, { onConflict: "match_id,player_id" })
        .select()
        .single();
      if (appErr) throw appErr;

      // Batting — simple insert (one per appearance)
      if (p.batting && (p.batting.runs ?? p.batting.fours ?? p.batting.sixes ?? p.batting.balls) !== undefined) {
        await supabase.from("batting_innings").insert({
          appearance_id: app!.id,
          runs: p.batting.runs ?? null,
          fours: p.batting.fours ?? null,
          sixes: p.batting.sixes ?? null,
          balls: p.batting.balls ?? null,
        });
      }

      // Bowling — simple insert (one per appearance)
      if (p.bowling && (p.bowling.overs ?? p.bowling.wickets ?? p.bowling.maidens ?? p.bowling.runs) !== undefined) {
        await supabase.from("bowling_spells").insert({
          appearance_id: app!.id,
          overs: p.bowling.overs ?? null,
          maidens: p.bowling.maidens ?? null,
          runs: p.bowling.runs ?? null,
          wickets: p.bowling.wickets ?? null,
          wides: p.bowling.wides ?? null,
          no_balls: p.bowling.no_balls ?? null,
        });
      }

      // Fielding extras -> one row per event (matches our schema: event_type + qty)
      const extras = p.extras || ({} as any);
      const events: Array<{ event_type: string; qty: number }> = [];
      if (extras.catches)   events.push({ event_type: "catch",   qty: extras.catches });
      if (extras.stumpings) events.push({ event_type: "stumping", qty: extras.stumpings });
      if (extras.runouts)   events.push({ event_type: "runout",   qty: extras.runouts });
      if (extras.assists)   events.push({ event_type: "assist",   qty: extras.assists });
      if (extras.drops)     events.push({ event_type: "drop",     qty: extras.drops });
      if (extras.ducks)     events.push({ event_type: "duck",     qty: extras.ducks });

      for (const ev of events) {
        await supabase.from("fielding_events").insert({
          appearance_id: app!.id,
          event_type: ev.event_type,
          qty: ev.qty,
        });
      }

      // Points per appearance
      const pts = calcPoints(
        { runs: p.batting?.runs, fours: p.batting?.fours, sixes: p.batting?.sixes },
        { wickets: p.bowling?.wickets, maidens: p.bowling?.maidens },
        { catches: extras.catches || 0, stumpings: extras.stumpings || 0, runouts: extras.runouts || 0, assists: extras.assists || 0 },
        { ducks: extras.ducks || 0, drops: extras.drops || 0 },
        cfg
      );

      await supabase.from("mvp_points").upsert(
        {
          appearance_id: app!.id,
          batting_points: pts.battingPts,
          bowling_points: pts.bowlingPts,
          fielding_points: pts.fieldingPts,
          penalty_points: pts.penaltyPts,
        },
        { onConflict: "appearance_id" }
      );

      appearanceTotals.push({ player: p.name, total: pts.total });
    }

    // ---- 3) Match summary (score + MVP)
    const mvp = appearanceTotals.sort((a, b) => b.total - a.total)[0];

    await supabase.from("match_summary").insert({
      match_id: matchRow.id,
      team: m.team,
      opponent: m.opponent,
      match_date: m.matchDate,
      venue: m.venue || null,
      result: null,
      team_score: m.teamScore || null,
      opponent_score: m.opponentScore || null,
      mvp_player: mvp?.player || null,
      mvp_points: mvp?.total ?? null,
    });

    saved.push({ matchId: matchRow.id, playCricketId: m.playCricketId });
  }

  return saved;
}
