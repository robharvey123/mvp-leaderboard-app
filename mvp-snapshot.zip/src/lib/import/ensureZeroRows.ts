// src/lib/import/ensureZeroRows.ts
import { supabase } from "../../lib/supabaseClient";

/**
 * Ensure every squad player has zeroed batting/bowling/fielding rows for a match.
 * Call this AFTER you insert the match + any parsed scorecard rows.
 */
export async function ensureZeroRows(matchId: string) {
  // 1) Get match context (team/club/date)
  const { data: m, error: mErr } = await supabase
    .from("matches")
    .select("id, club_id, team_id, match_date")
    .eq("id", matchId)
    .maybeSingle();
  if (mErr || !m) throw mErr || new Error("Match not found");

  // 2) Find season by date (or your own season_id if you store it on matches)
  const { data: s, error: sErr } = await supabase
    .from("seasons")
    .select("id")
    .eq("club_id", m.club_id)
    .lte("start_date", m.match_date)
    .gte("end_date", m.match_date)
    .order("is_active", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (sErr || !s) throw sErr || new Error("Season not found for match date");

  // 3) Squad for that team/season
  const { data: squad, error: qErr } = await supabase
    .from("squads")
    .select("player_id")
    .eq("team_id", m.team_id)
    .eq("season_id", s.id);
  if (qErr) throw qErr;

  const playerIds = (squad || []).map((r) => r.player_id);
  if (playerIds.length === 0) return;

  // Helper to get existing players per table
  async function existing(table: string) {
    const { data, error } = await supabase
      .from(table)
      .select("player_id")
      .eq("match_id", matchId);
    if (error) throw error;
    return new Set((data || []).map((r: any) => r.player_id));
  }

  const [haveBat, haveBowl, haveField] = await Promise.all([
    existing("batting_cards"),
    existing("bowling_cards"),
    existing("fielding_cards"),
  ]);

  const missingBat = playerIds.filter((id) => !haveBat.has(id));
  const missingBowl = playerIds.filter((id) => !haveBowl.has(id));
  const missingField = playerIds.filter((id) => !haveField.has(id));

  const batRows = missingBat.map((player_id) => ({
    match_id: matchId,
    player_id,
    position: null,
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
    strike_rate: null,
    // derived: true, // optional if you add a column
  }));
  const bowlRows = missingBowl.map((player_id) => ({
    match_id: matchId,
    player_id,
    overs: 0,
    maidens: 0,
    runs: 0,
    wickets: 0,
    economy: null,
    // derived: true,
  }));
  const fieldRows = missingField.map((player_id) => ({
    match_id: matchId,
    player_id,
    catches: 0,
    stumpings: 0,
    runouts: 0,
    drops: 0,
    misfields: 0,
    // derived: true,
  }));

  // 4) Batch insert the missing rows
  if (batRows.length) await supabase.from("batting_cards").insert(batRows);
  if (bowlRows.length) await supabase.from("bowling_cards").insert(bowlRows);
  if (fieldRows.length) await supabase.from("fielding_cards").insert(fieldRows);
}
