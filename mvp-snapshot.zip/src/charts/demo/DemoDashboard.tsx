import { LeaderboardTopPointsBar, TopBatterPointsBar, TopBowlerPointsBar, TopFielderPointsBar, MatchByMatchLine, TeamStatsTiles, TopRunScorerBar, TopWicketTakerBar, MostCatchesBar, BigBoySixesBar, FourChampionBar, ButterFingersBar, DuckLeaderboardBar, TopPerformanceTable, CombinedDashboard } from '../index';
import type { PlayerSeason, PlayerMatch, TeamStats } from '../utils/mvpTypes';

const players: PlayerSeason[] = [
  { player: 'Danny Finch', totalPoints: 1699, battingPoints: 1181, bowlingPoints: 405, fieldingPoints: 90 },
  { player: 'Saf Abbas', totalPoints: 1375, battingPoints: 592, bowlingPoints: 735, fieldingPoints: 50 },
  { player: 'Alfie Hedges', totalPoints: 1355, battingPoints: 815, bowlingPoints: 465, fieldingPoints: 100 },
  { player: 'Rob Harvey', totalPoints: 1105, battingPoints: 970, bowlingPoints: 135, fieldingPoints: 30 },
  { player: 'Armaan AliShah', totalPoints: 854, battingPoints: 666, bowlingPoints: 185, fieldingPoints: 10 },
];

const matches: PlayerMatch[] = [
  { player: 'Danny Finch', matchId: '2025-05-17-OCC', matchDate: '2025-05-17', totalPoints: 160 },
  { player: 'Danny Finch', matchId: '2025-06-14-EHC', matchDate: '2025-06-14', totalPoints: 243 },
  { player: 'Danny Finch', matchId: '2025-07-26-GW', matchDate: '2025-07-26', totalPoints: 294 },
  { player: 'Danny Finch', matchId: '2025-08-09-RAY', matchDate: '2025-08-09', totalPoints: 277 },
];

const teamStats: TeamStats = {
  runs: 5059, fifties: 23, hundreds: 9, fours: 710, sixes: 59,
  wickets: 219, fiveFors: 5, maidens: 118, catches: 104,
  runOuts: 2, assists: 7.5, stumpings: 9, ducks: 25, drops: 57,
};

export default function DemoDashboard() {
  return (
    <div className="space-y-6 p-6">
      <TeamStatsTiles stats={teamStats} />
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <TopRunScorerBar data={players} topN={5} />
        <TopWicketTakerBar data={players} topN={5} />
        <MostCatchesBar data={players} topN={5} />
        <BigBoySixesBar data={players} topN={5} />
        <FourChampionBar data={players} topN={5} />
        <ButterFingersBar data={players} topN={5} />
        <DuckLeaderboardBar data={players} topN={5} />
        <LeaderboardTopPointsBar data={players} topN={5} />
        <TopBatterPointsBar data={players} topN={5} />
        <TopBowlerPointsBar data={players} topN={5} />
        <TopFielderPointsBar data={players} topN={5} />
      </div>
      <MatchByMatchLine data={matches} player="Danny Finch" metric="totalPoints" />
    </div>
  );
}
