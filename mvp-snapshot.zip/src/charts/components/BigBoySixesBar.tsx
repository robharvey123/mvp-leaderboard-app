import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

/** Big Boy 6 Champion */
export function BigBoySixesBar({ data, topN = 10, title = 'Big Boy 6 Champion' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.sixes ?? 0) - (a.sixes ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.sixes ?? 0 }))} />;
}
