import { useMemo, useState } from 'react';
import type { PlayerSeason, PlayerMatch, TeamStats } from '../../utils/mvpTypes';
import { TeamSelector } from './TeamSelector';
import { TeamStatsTiles } from './TeamStatsTiles';
import { LeaderboardTopPointsBar } from './LeaderboardTopPointsBar';
import { TopBatterPointsBar } from './TopBatterPointsBar';
import { TopBowlerPointsBar } from './TopBowlerPointsBar';
import { TopFielderPointsBar } from './TopFielderPointsBar';
import { TopRunScorerBar } from './TopRunScorerBar';
import { TopWicketTakerBar } from './TopWicketTakerBar';
import { MostCatchesBar } from './MostCatchesBar';
import { BigBoySixesBar } from './BigBoySixesBar';
import { FourChampionBar } from './FourChampionBar';
import { ButterFingersBar } from './ButterFingersBar';
import { DuckLeaderboardBar } from './DuckLeaderboardBar';
import { MatchByMatchLine } from './MatchByMatchLine';
import { TopPerformanceTable } from './TopPerformanceTable';

type Map = Record<string, PlayerSeason[]>;
type MatchMap = Record<string, PlayerMatch[]>;
type StatsMap = Record<string, TeamStats>;

export function CombinedDashboard({
  teams,
  teamStatsByTeam,
  playersByTeam,
  matchesByTeam,
  defaultTeam,
}: {
  teams: { label: string; value: string }[];
  teamStatsByTeam: StatsMap;
  playersByTeam: Map;
  matchesByTeam: MatchMap;
  defaultTeam?: string;
}) {
  const [team, setTeam] = useState(defaultTeam || teams[0]?.value || '');
  const players = playersByTeam[team] || [];
  const matches = matchesByTeam[team] || [];
  const stats = teamStatsByTeam[team] || {};

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">MVP Dashboard</h2>
        <TeamSelector options={teams} value={team} onChange={setTeam} />
      </div>

      <TeamStatsTiles stats={stats} />

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <LeaderboardTopPointsBar data={players} topN={10} />
        <TopBatterPointsBar data={players} topN={10} />
        <TopBowlerPointsBar data={players} topN={10} />
        <TopFielderPointsBar data={players} topN={10} />
        <TopRunScorerBar data={players} topN={10} />
        <TopWicketTakerBar data={players} topN={10} />
        <MostCatchesBar data={players} topN={10} />
        <BigBoySixesBar data={players} topN={10} />
        <FourChampionBar data={players} topN={10} />
        <ButterFingersBar data={players} topN={10} />
        <DuckLeaderboardBar data={players} topN={10} />
      </div>

      <MatchByMatchLine data={matches} player={players[0]?.player || ''} metric="totalPoints" />

      {/* For Top performances, the input should be match-level objects */}
      <TopPerformanceTable data={matches as any} topN={10} />
    </div>
  );
}
