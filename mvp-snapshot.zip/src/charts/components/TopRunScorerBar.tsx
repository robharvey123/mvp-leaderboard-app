import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

export function TopRunScorerBar({ data, topN = 10, title = 'Top Run Scorer' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.runs ?? 0) - (a.runs ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.runs ?? 0 }))} />;
}
