import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

type Datum = { name: string; value: number };

export function HorizontalBar({ data, title, height = 288 }: { data: Datum[]; title: string; height?: number }) {
  const chartData = [...data].reverse();
  return (
    <div className="w-full p-4 bg-white/5 rounded-2xl shadow-sm">
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} layout="vertical" margin={{ left: 24, right: 16 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" />
            <YAxis type="category" dataKey="name" width={140} />
            <Tooltip />
            <Bar dataKey="value" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
