import type { PlayerMatch } from '../../utils/mvpTypes';

type Perf = PlayerMatch & {
  runs?: number;
  fifties?: number;
  hundreds?: number;
  fiveWickets?: number;
  wickets?: number;
  catches?: number;
};

export function TopPerformanceTable({ data, topN = 10, title = 'Top Performances' }: { data: Perf[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.totalPoints ?? 0) - (a.totalPoints ?? 0)).slice(0, topN);
  return (
    <div className="w-full p-4 bg-white/5 rounded-2xl shadow-sm overflow-x-auto">
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <table className="min-w-[720px] w-full text-sm">
        <thead className="text-left opacity-70">
          <tr>
            <th className="py-2 pr-4">#</th>
            <th className="py-2 pr-4">Player</th>
            <th className="py-2 pr-4">Match</th>
            <th className="py-2 pr-4">Runs</th>
            <th className="py-2 pr-4">50</th>
            <th className="py-2 pr-4">100</th>
            <th className="py-2 pr-4">5 Wkts</th>
            <th className="py-2 pr-4">Wkts</th>
            <th className="py-2 pr-4">Catches</th>
            <th className="py-2 pr-4">Total Pts</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx)=> (
            <tr key={idx} className="border-t border-white/10">
              <td className="py-2 pr-4">{idx+1}.</td>
              <td className="py-2 pr-4">{r.player}</td>
              <td className="py-2 pr-4">{r.matchId}</td>
              <td className="py-2 pr-4">{r.runs ?? '—'}</td>
              <td className="py-2 pr-4">{r.fifties ?? 0}</td>
              <td className="py-2 pr-4">{r.hundreds ?? 0}</td>
              <td className="py-2 pr-4">{r.fiveWickets ?? 0}</td>
              <td className="py-2 pr-4">{r.wickets ?? '—'}</td>
              <td className="py-2 pr-4">{r.catches ?? '—'}</td>
              <td className="py-2 pr-4 font-semibold">{r.totalPoints ?? 0}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
