import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

export function MostCatchesBar({ data, topN = 10, title = 'Most Catches' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.catches ?? 0) - (a.catches ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.catches ?? 0 }))} />;
}
