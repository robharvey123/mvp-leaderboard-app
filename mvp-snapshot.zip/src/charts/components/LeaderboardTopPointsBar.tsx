import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { PlayerSeason } from '../../utils/mvpTypes';

export function LeaderboardTopPointsBar({ data, topN = 10, title = 'Top Points' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const sorted = [...data].sort((a, b) => (b.totalPoints ?? 0) - (a.totalPoints ?? 0)).slice(0, topN);
  const chartData = sorted.map(d => ({
    name: d.player,
    value: d.totalPoints ?? 0,
  })).reverse(); // reverse for horizontal top-down

  return (
    <div className="w-full p-4 bg-white/5 rounded-2xl shadow-sm">
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} layout="vertical" margin={{ left: 24, right: 16 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" />
            <YAxis type="category" dataKey="name" width={120} />
            <Tooltip />
            <Bar dataKey="value" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
