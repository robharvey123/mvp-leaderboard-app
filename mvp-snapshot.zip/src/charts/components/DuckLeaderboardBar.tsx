import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

/** Duck Leaderboard */
export function DuckLeaderboardBar({ data, topN = 10, title = 'Duck Leaderboard' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.ducks ?? 0) - (a.ducks ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.ducks ?? 0 }))} />;
}
