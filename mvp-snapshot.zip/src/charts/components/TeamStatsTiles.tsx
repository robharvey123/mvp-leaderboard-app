import type { TeamStats } from '../../utils/mvpTypes';
import { Trophy, Target, Bat, Medal } from 'lucide-react';

const Stat = ({ label, value }: { label: string; value?: number | string }) => (
  <div className="bg-white/5 rounded-2xl p-4">
    <div className="text-sm opacity-80">{label}</div>
    <div className="text-2xl font-semibold">{value ?? '—'}</div>
  </div>
);

export function TeamStatsTiles({ stats, title = 'Team Stats' }: { stats: TeamStats; title?: string }) {
  return (
    <div className="w-full p-4 bg-white/5 rounded-2xl shadow-sm">
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3">
        <Stat label="Runs" value={stats.runs} />
        <Stat label="50's" value={stats.fifties} />
        <Stat label="100's" value={stats.hundreds} />
        <Stat label="4's" value={stats.fours} />
        <Stat label="6's" value={stats.sixes} />
        <Stat label="Wickets" value={stats.wickets} />
        <Stat label="5-fors" value={stats.fiveFors} />
        <Stat label="Maidens" value={stats.maidens} />
        <Stat label="Catches" value={stats.catches} />
        <Stat label="Run-Outs" value={stats.runOuts} />
        <Stat label="Assists" value={stats.assists} />
        <Stat label="Stumpings" value={stats.stumpings} />
        <Stat label="Ducks" value={stats.ducks} />
        <Stat label="Drops" value={stats.drops} />
      </div>
    </div>
  );
}
