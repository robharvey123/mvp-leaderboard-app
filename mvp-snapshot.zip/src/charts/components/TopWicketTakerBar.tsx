import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

export function TopWicketTakerBar({ data, topN = 10, title = 'Top Wicket Taker' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.wickets ?? 0) - (a.wickets ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.wickets ?? 0 }))} />;
}
