import React from 'react';
import type { PlayerSeason } from '../../utils/mvpTypes';

type Option = { label: string; value: string };
type Props = {
  options: Option[];
  value: string;
  onChange: (val: string)=> void;
};

export function TeamSelector({ options, value, onChange }: Props) {
  return (
    <div className="flex items-center gap-3">
      <label className="text-sm opacity-80">Team</label>
      <select
        className="px-3 py-2 rounded-xl bg-white/5 border border-white/10"
        value={value}
        onChange={(e)=> onChange(e.target.value)}
      >
        {options.map(opt=> <option key={opt.value} value={opt.value}>{opt.label}</option>)}
      </select>
    </div>
  );
}
