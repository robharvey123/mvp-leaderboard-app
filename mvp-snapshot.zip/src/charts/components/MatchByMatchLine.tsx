import { Line, LineChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { PlayerMatch } from '../../utils/mvpTypes';

/**
 * Match-by-match trend for a single player and metric (eg totalPoints, battingPoints).
 */
type Props = {
  data: PlayerMatch[];
  player: string;
  metric?: keyof PlayerMatch; // default 'totalPoints'
  title?: string;
};

export function MatchByMatchLine({ data, player, metric = 'totalPoints', title }: Props) {
  const rows = data.filter(d => d.player === player).sort((a, b) => (a.matchDate > b.matchDate ? 1 : -1));
  const chartData = rows.map(d => ({ date: d.matchDate, value: (d as any)[metric] ?? 0 }));
  const header = title || `${player} – ${String(metric)} over time`;

  return (
    <div className="w-full p-4 bg-white/5 rounded-2xl shadow-sm">
      <h3 className="text-lg font-semibold mb-3">{header}</h3>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ left: 16, right: 16 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="value" dot />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
