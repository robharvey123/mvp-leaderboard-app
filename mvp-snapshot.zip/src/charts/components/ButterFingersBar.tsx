import type { PlayerSeason } from '../../utils/mvpTypes';
import { HorizontalBar } from './HorizontalBar';

/** Butter Fingers Cup */
export function ButterFingersBar({ data, topN = 10, title = 'Butter Fingers Cup' }: { data: PlayerSeason[]; topN?: number; title?: string }) {
  const rows = [...data].sort((a,b)=> (b.dropped ?? 0) - (a.dropped ?? 0)).slice(0, topN);
  return <HorizontalBar title={title!} data={rows.map(r=>({ name: r.player, value: r.dropped ?? 0 }))} />;
}
