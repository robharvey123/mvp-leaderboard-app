export type PlayerSeason = {
  player: string;
  totalPoints?: number;
  battingPoints?: number;
  bowlingPoints?: number;
  fieldingPoints?: number;
  penaltyPoints?: number;
  runs?: number;
  wickets?: number;
  catches?: number;
  sixes?: number;
  fours?: number;
  hundreds?: number;
  fifties?: number;
  maidens?: number;
  dropped?: number;
};

export type PlayerMatch = {
  player: string;
  matchId: string;
  matchDate: string; // ISO date
  opponent?: string;
  team?: string;
  totalPoints?: number;
  battingPoints?: number;
  bowlingPoints?: number;
  fieldingPoints?: number;
  penaltyPoints?: number;
};

export type TeamStats = {
  runs?: number;
  fifties?: number;
  hundreds?: number;
  fours?: number;
  sixes?: number;
  wickets?: number;
  fiveFors?: number;
  maidens?: number;
  catches?: number;
  runOuts?: number;
  assists?: number;
  stumpings?: number;
  ducks?: number;
  drops?: number;
};
