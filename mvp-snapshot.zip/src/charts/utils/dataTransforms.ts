import type { PlayerSeason, PlayerMatch } from './mvpTypes';

/**
 * Sort utility with nullish safe numbers.
 */
const num = (v: number | undefined | null) => (typeof v === 'number' ? v : 0);

/**
 * Return top N by a numeric key.
 */
export function topN<T extends Record<string, any>>(arr: T[], key: keyof T, n = 10): T[] {
  return [...arr].sort((a, b) => num(b[key] as number) - num(a[key] as number)).slice(0, n);
}

/**
 * Map raw CSV rows to PlayerSeason (example). Adjust the field mapping to your actual CSV headers.
 */
export function mapCsvRowToPlayerSeason(row: Record<string, string>): PlayerSeason {
  return {
    player: row['Player'],
    totalPoints: parseFloat(row['Total Points'] || '0'),
    battingPoints: parseFloat(row['Batting Points'] || '0'),
    bowlingPoints: parseFloat(row['Bowling Points'] || '0'),
    fieldingPoints: parseFloat(row['Fielding Points'] || '0'),
    penaltyPoints: parseFloat(row['Penalty Points'] || '0'),
    runs: parseFloat(row['Runs'] || '0'),
    wickets: parseFloat(row['Wickets'] || '0'),
    catches: parseFloat(row['Catches'] || '0'),
    sixes: parseFloat(row['6\'s'] || row['6s'] || '0'),
    fours: parseFloat(row['4\'s'] || row['4s'] || '0'),
    hundreds: parseFloat(row['100\'s'] || row['100s'] || '0'),
    fifties: parseFloat(row['50\'s'] || row['50s'] || '0'),
    maidens: parseFloat(row['Maidens'] || '0'),
    dropped: parseFloat(row['Dropped Catch'] || row['Drops'] || '0'),
  };
}

/**
 * Map raw CSV rows to PlayerMatch (example).
 */
export function mapCsvRowToPlayerMatch(row: Record<string, string>): PlayerMatch {
  return {
    player: row['Player'],
    matchId: row['Match Id'] || `${row['Date']}-${row['Opponent']}`,
    matchDate: row['Date'],
    opponent: row['Opponent'],
    team: row['Team'],
    totalPoints: parseFloat(row['Total Points'] || '0'),
    battingPoints: parseFloat(row['Batting Points'] || '0'),
    bowlingPoints: parseFloat(row['Bowling Points'] || '0'),
    fieldingPoints: parseFloat(row['Fielding Points'] || '0'),
    penaltyPoints: parseFloat(row['Penalty Points'] || '0'),
  };
}
