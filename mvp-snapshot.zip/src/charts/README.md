# Pack 4 – Charts (MVP App)

Drop these files into your React + Vite + TypeScript project (we use Tailwind + Recharts).  
You’ll get ready-to-use charts that match your MVP PDFs: **Top Batter Points**, **Top Bowler Points**, **Top Fielder Points**, **Overall Top Points**, **Team KPI tiles**, and a **Match-by-Match trend**.

## Install peer deps

```bash
npm i recharts lucide-react
# or
yarn add recharts lucide-react
```

Tailwind is optional for the styling classes shown. If you're not using Tailwind, you can replace classes with your own CSS.

## Files
- `src/components/LeaderboardTopPointsBar.tsx`
- `src/components/TopBatterPointsBar.tsx`
- `src/components/TopBowlerPointsBar.tsx`
- `src/components/TopFielderPointsBar.tsx`
- `src/components/MatchByMatchLine.tsx`
- `src/components/TeamStatsTiles.tsx`
- `src/utils/mvpTypes.ts`
- `src/utils/dataTransforms.ts`
- `src/demo/DemoDashboard.tsx` (optional example)
- `src/index.ts`

## Data shape

We keep types simple and flexible.

```ts
// Player season aggregate
export type PlayerSeason = {
  player: string;
  totalPoints?: number;
  battingPoints?: number;
  bowlingPoints?: number;
  fieldingPoints?: number;
  penaltyPoints?: number;
  runs?: number;
  wickets?: number;
  catches?: number;
  sixes?: number;
  fours?: number;
  hundreds?: number;
  fifties?: number;
  maidens?: number;
  dropped?: number; // dropped catches
};

// A single player match record (for trend charts)
export type PlayerMatch = {
  player: string;
  matchId: string; // e.g., '2025-07-26-vs-Great-Wakering'
  matchDate: string; // ISO '2025-07-26'
  opponent?: string;
  team?: string; // 1st XI, 2nd XI, etc.
  totalPoints?: number;
  battingPoints?: number;
  bowlingPoints?: number;
  fieldingPoints?: number;
  penaltyPoints?: number;
};
```

If your data comes from Supabase or CSV, map to the above using the helpers in `dataTransforms.ts`.

## Quick use

```tsx
import { LeaderboardTopPointsBar, TopBatterPointsBar, TopBowlerPointsBar, TopFielderPointsBar, MatchByMatchLine, TeamStatsTiles } from "./charts"; // or relative path

// Example inside a page:
<LeaderboardTopPointsBar data={players} topN={10} title="Top Points" />
<TopBatterPointsBar data={players} topN={10} />
<TopBowlerPointsBar data={players} topN={10} />
<TopFielderPointsBar data={players} topN={10} />
<MatchByMatchLine data={playerMatches} player="Danny Finch" metric="totalPoints" />
<TeamStatsTiles stats={teamStats} />
```

## Team KPIs

`TeamStatsTiles` expects a simple object like:

```ts
const teamStats = {
  runs: 5059,
  fifties: 23,
  hundreds: 9,
  fours: 710,
  sixes: 59,
  wickets: 219,
  fiveFors: 5,
  maidens: 118,
  catches: 104,
  runOuts: 2,
  assists: 7.5,
  stumpings: 9,
  ducks: 25,
  drops: 57,
};
```

## Demo

Use `DemoDashboard.tsx` for an all-in-one preview of the components with mock data.


## Extras now included (full pack)
- `TopRunScorerBar`
- `TopWicketTakerBar`
- `MostCatchesBar`
- `BigBoySixesBar` (sixes)
- `FourChampionBar` (fours)
- `ButterFingersBar` (drops)
- `DuckLeaderboardBar`
- `TopPerformanceTable` (single-match list)
- `TeamSelector`
- `CombinedDashboard` (switch between squads like 1st XI, 2nd XI, Overall)
